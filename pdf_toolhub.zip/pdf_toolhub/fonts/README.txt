Drop free Unicode .ttf fonts here (e.g. from https://fonts.google.com/noto):
  NotoSansTelugu-Regular.ttf, NotoSansDevanagari-Regular.ttf, NotoSansTamil-Regular.ttf ...
Fonts in this folder are used first by Text -> PDF, Watermark and Page numbers.
For correct joining of Indic scripts also run:  pip install uharfbuzz
